from django.db import models

# Create your models here.



class Categorie(models.Model):
    nume = models.CharField(max_length=100)
    descriere = models.TextField(blank=True, null=True)
    activa = models.BooleanField(default=True)
    an = models.IntegerField(blank=True, null=True)
    tematica = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return self.nume


class Marca(models.Model):
    nume = models.CharField(max_length=100, unique=True)
    tara_origine = models.CharField(max_length=100, blank=True, null=True)
    descriere = models.TextField(blank=True, null=True)
    premium = models.BooleanField(default=False)
    procent_discount_max = models.FloatField(default=0)

    def __str__(self):
        return self.nume


class Culoare(models.Model):
    nume = models.CharField(max_length=50)
    cod_hex = models.CharField(max_length=7, unique=True)
    culoare_fav = models.BooleanField(default=False)
    culoare_recomandata = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.nume} ({self.cod_hex})"


class Marime(models.Model):
    denumire = models.CharField(max_length=50)
    tip_marime = models.CharField(max_length=50)
    ordine_afisare = models.IntegerField(default=10)
    disponibilitate = models.BooleanField(default=True)
    stare = models.CharField(max_length=50, blank=True, null=True)

    def __str__(self):
        return f"{self.denumire} ({self.tip_marime})"


class Discount(models.Model):
    cod_discount = models.CharField(max_length=20, unique=True)
    procent_reducere = models.FloatField()
    data_inceput = models.DateTimeField()
    data_sfarsit = models.DateTimeField()
    activ = models.BooleanField(default=True)
    descriere = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.cod_discount} ({self.procent_reducere}%)"


class Colectie(models.Model):
    nume = models.CharField(max_length=100)
    sezon = models.CharField(max_length=100, blank=True, null=True)
    cod_sku = models.CharField(max_length=50, unique=True)

    pret_min = models.FloatField(default=0)
    pret_max = models.FloatField(default=0)

    categorie = models.ForeignKey(
        Categorie, on_delete=models.SET_NULL, null=True, related_name="colectie"
    )

    marci = models.ManyToManyField(Marca, related_name="colectie")

    def __str__(self):
        return f"{self.nume} ({self.cod_sku})"


class Produs(models.Model):
    nume_produs = models.CharField(max_length=255)
    descriere = models.TextField()
    material = models.CharField(max_length=100, blank=True, null=True)
    pret = models.FloatField(default=0)
    gen = models.CharField(max_length=50, default="Unisex")
    data_adaugare = models.DateTimeField(auto_now_add=True)

    colectie = models.ForeignKey(
        Colectie, on_delete=models.SET_NULL, null=True, related_name="produs"
    )
    culoare = models.ForeignKey(
        Culoare, on_delete=models.SET_NULL, null=True, related_name="produs"
    )
    discount = models.ForeignKey(
        Discount, on_delete=models.SET_NULL, null=True, blank=True, related_name="produs"
    )

    marimi = models.ManyToManyField(Marime, related_name="produs")

    def __str__(self):
        return self.nume_produs
    
class ProdusImage(models.Model):
    produs = models.ForeignKey(
        Produs,
        on_delete=models.CASCADE,
        related_name="imagini"
    )
    imagine = models.ImageField(upload_to="produse/", null=True, blank=True)

    def __str__(self):
        return f"Imagine pentru {self.produs.nume_produs}"
