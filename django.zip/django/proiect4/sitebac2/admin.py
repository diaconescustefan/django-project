from django.contrib import admin
from .models import Categorie, Marca, Culoare, Marime, Discount, Colectie, Produs,ProdusImage

admin.site.site_header = "Magazin Fashion - Panou Administrativ"
admin.site.site_title = "Administrare Magazin Fashion"
admin.site.index_title = "Bun venit în zona de administrare"


# --------------------- CATEGORIE ADMIN ---------------------
@admin.register(Categorie)
class CategorieAdmin(admin.ModelAdmin):
    search_fields = ['nume', 'descriere']


# --------------------- MARCA ADMIN ---------------------
@admin.register(Marca)
class MarcaAdmin(admin.ModelAdmin):
    search_fields = ['nume', 'descriere']


# --------------------- CULOARE ADMIN ---------------------
@admin.register(Culoare)
class CuloareAdmin(admin.ModelAdmin):
    search_fields = ['nume', 'cod_hex']


# --------------------- MARIME ADMIN ---------------------
@admin.register(Marime)
class MarimeAdmin(admin.ModelAdmin):
    search_fields = ['denumire', 'tip_marime']


# --------------------- DISCOUNT ADMIN ---------------------
@admin.register(Discount)
class DiscountAdmin(admin.ModelAdmin):
    search_fields = ['cod_discount', 'descriere']


# --------------------- COLECTIE ADMIN ---------------------
@admin.register(Colectie)
class ColectieAdmin(admin.ModelAdmin):
    search_fields = ['nume', 'cod_sku']


# --------------------- PRODUS ADMIN ---------------------

class ProdusImageInline(admin.TabularInline):
    model = ProdusImage
    extra = 1
    
    
@admin.register(Produs)
class ProdusAdmin(admin.ModelAdmin):
    list_display = ['nume_produs', 'pret', 'gen', 'colectie', 'culoare']
    search_fields = ['nume_produs', 'descriere']
    ordering = ['-pret']
    inlines = [ProdusImageInline]
    list_filter = ['gen', 'colectie', 'culoare', 'discount']
    list_per_page = 5
    fieldsets = [
    ('Informații generale', {
        'fields': ('nume_produs', 'descriere', 'material'),
    }),
    ('Detalii de configurare', {
        'classes': ('collapse',),
        'fields': ('pret', 'gen', 'colectie', 'culoare', 'marimi', 'discount'),
    }),
]
