from django.shortcuts import render
from django.http import HttpResponse
from datetime import datetime
from urllib.parse import urlparse
from .models import Produs
from collections import Counter
import json

# ===== CLASE ȘI FUNCȚII AJUTĂTOARE =====

class Accesare:
    """Clasă simplă pentru a salva o accesare"""
    
    id_urmator = 1
    
    def __init__(self, url, data):
        """Creează o accesare nouă"""
        self.id = Accesare.id_urmator  
        Accesare.id_urmator += 1       
        self.url = url                 
        self.data = data                # Data este deja string formatat
    
    def __str__(self):
        """Pentru afișare simplă"""
        return f"ID: {self.id} | {self.url} - {self.data}"


# Lista pentru loguri
loguri = []


def salveaza_accesare(request):
    """Salvează accesarea curentă în lista de loguri"""
    full_url = request.get_full_path()
    
    # Formatăm data în format românesc
    data_formatata = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    new_log = Accesare(
        url=full_url,
        data=data_formatata 
    )
    loguri.append(new_log)
    return new_log


# ===== FUNCȚII NOI: DATA ȘI IP =====

def data_romana():
    """Returnează data curentă în format românesc"""
    zile = ["luni", "marți", "miercuri", "joi", "vineri", "sâmbătă", "duminică"]
    luni = ["ianuarie", "februarie", "martie", "aprilie", "mai", "iunie",
            "iulie", "august", "septembrie", "octombrie", "noiembrie", "decembrie"]
    azi = datetime.now()
    return f"{zile[azi.weekday()]}, {azi.day} {luni[azi.month - 1]} {azi.year}"

def get_ip(request):
    """Returnează adresa IP a utilizatorului"""
    return request.META.get('REMOTE_ADDR', 'necunoscut')


# ===== VIEWS PENTRU PAGINI DE BAZĂ =====

def index(request):
    """Pagina principală"""
    salveaza_accesare(request)
    context = {
        'data_curenta': data_romana(),
        'ip_user': get_ip(request)
    }
    return HttpResponse(f"""
        <h1>Despre site-ul nostru de haine</h1>
        <p>
        Acest proiect reprezintă un <strong>site de prezentare și vânzare de haine online</strong>, realizat în <strong>Django</strong>.
        Platforma permite afișarea produselor pe categorii și mărci, cu imagini, prețuri și descrieri detaliate.
        Fiecare produs poate fi vizualizat în mai multe <strong>variante de culoare și mărime</strong>.
        Scopul site-ului este de a oferi utilizatorilor o experiență simplă și modernă de navigare printre articole vestimentare.
        </p>
        <hr>
        <p><strong>Data curentă:</strong> {context['data_curenta']}</p>
        <p><strong>IP-ul tău:</strong> {context['ip_user']}</p>
    """)


zile_romana = {
    0:"luni",
    1:"marti",
    2:"miercuri",
    3:"joi",
    4:"vineri",
    5:"sambata",
    6:"duminica"
}
luni_romana = {
    1:"ianuarie",
    2:"februarie",
    3:"martie",
    4:"aprilie",
    5:"mai",
    6:"iunie",
    7:"iulie",
    8:"august",
    9:"septembrie",
    10:"octombrie",
    11:"noiembrie",
    12:"decembrie"
}

def info(request):
    """Pagina info"""
    salveaza_accesare(request)
    
    intrare = request.GET.get("data")
    data = datetime.now()
    data_indice = data.weekday()
    luna_indice = data.month

    if intrare == "zi":
        data_curenta = f"{zile_romana[data_indice]} {data.day}  {luni_romana[luna_indice]} {data.year}"
    elif intrare == "timp":
        data_curenta = data.strftime("%H:%M:%S")
    else:
        data_curenta = f"{zile_romana[data_indice]} {data.day}  {luni_romana[luna_indice]} {data.year} {data.strftime('%H:%M:%S')}"
    
    ip_user = get_ip(request)

    return HttpResponse(f"""
        <html>
        <body>
            <h1>Informatii despre server</h1>
            <p>{data_curenta}</p>
            <p>Adresa ta IP: {ip_user}</p>
        </body>
        </html>
    """)


def invata(request):
    """Pagina învață"""
    salveaza_accesare(request)
    context = {
        'data_curenta': data_romana(),
        'ip_user': get_ip(request)
    }
    return HttpResponse(f"""
        <h1>Pagina învață</h1>
        <p>Data curentă: {context['data_curenta']}</p>
        <p>IP-ul tău: {context['ip_user']}</p>
    """)


# ===== VIEW PENTRU LOG (Task 1) =====

def log(request):
    """Afișează logurile cu toate cerințele"""
    salveaza_accesare(request)
    
    # CERINȚA 2: Parametrul "ultimele"
    cate_sa_aratam = len(loguri)
    
    if 'ultimele' in request.GET:
        try:
            cate_sa_aratam = int(request.GET['ultimele'])
            if cate_sa_aratam <= 0:
                return HttpResponse("<h1 style='color:red'>Eroare: 'ultimele' trebuie > 0</h1>")
        except:
            return HttpResponse("<h1 style='color:red'>Eroare: 'ultimele' nu e număr valid</h1>")

    loguri_de_afisat = loguri[-cate_sa_aratam:] if loguri else []
    
    iduri_lista = request.GET.getlist('iduri') 
    
    if iduri_lista:
        try:
            id_uri_cerute = []
            for iduri_str in iduri_lista:
                id_uri = [int(id_str.strip()) for id_str in iduri_str.split(',')]
                id_uri_cerute.extend(id_uri)
            
            loguri_filtrate = []
            for id_cautat in id_uri_cerute:
                for accesare in loguri: 
                    if accesare.id == id_cautat:
                        loguri_filtrate.append(accesare)
                        break
            
            loguri_de_afisat = loguri_filtrate
            
            if len(loguri_de_afisat) == 0:
                return HttpResponse("<h1 style='color:red'>Nu s-au găsit accesări cu ID-urile cerute</h1>")
                
        except ValueError:
            return HttpResponse("<h1 style='color:red'>Eroare: 'iduri' trebuie să conțină ID-uri separate prin virgulă (ex: 2,3,5)</h1>")
    else:
        loguri_de_afisat = list(reversed(loguri_de_afisat))
    
    numarari = {}
    for accesare in loguri:
        url = accesare.url 
        if url in numarari:
            numarari[url] += 1
        else:
            numarari[url] = 1
    
    pagini_sortate = sorted(numarari.items(), key=lambda x: x[1], reverse=True)
    
    mesaj_eroare = None
    if 'ultimele' in request.GET and cate_sa_aratam > len(loguri):
        mesaj_eroare = f"Există doar {len(loguri)} accesări față de {cate_sa_aratam} cerute."
    
    context = {
        'loguri': loguri_de_afisat,
        'primul': loguri_de_afisat[0] if loguri_de_afisat else None,
        'total': len(loguri_de_afisat),
        'mesaj_eroare': mesaj_eroare,
        'pagini_sortate': pagini_sortate,
        'data_curenta': data_romana(),
        'ip_user': get_ip(request)
    }
    
    return render(request, 'sitebac2/log_implicit.html', context)


# ===== VIEWS PENTRU TASK 2 (Conținut) =====

def pagina_principala_view(request):
    """Pagina principală din secțiunea Conținut"""
    context = {
        'data_curenta': data_romana(),
        'ip_user': get_ip(request)
    }
    return render(request, 'sitebac2/pagina_principala.html', context)


def despre_view(request):
    """Pagina Despre"""
    context = {
        'data_curenta': data_romana(),
        'ip_user': get_ip(request)
    }
    return render(request, 'sitebac2/despre.html', context)


def produse_view(request):
    produse = Produs.objects.all()
    return render(request, 'sitebac2/produse.html', {'produse': produse})


def contact_view(request):
    """Pagina Contact"""
    context = {
        'data_curenta': data_romana(),
        'ip_user': get_ip(request)
    }
    return render(request, 'sitebac2/inlucru.html', context)


def cos_virtual_view(request):
    """Pagina Coș Virtual"""
    context = {
        'data_curenta': data_romana(),
        'ip_user': get_ip(request)
    }
    return render(request, 'sitebac2/inlucru.html', context)


def inlucru(request):
    """Pagina generică În Lucru"""
    context = {
        'data_curenta': data_romana(),
        'ip_user': get_ip(request)
    }
    return render(request, 'sitebac2/inlucru.html', context)

