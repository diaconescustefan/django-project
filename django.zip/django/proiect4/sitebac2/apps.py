from django.apps import AppConfig


class Sitebac2Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sitebac2'
