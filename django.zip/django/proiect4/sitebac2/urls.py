from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("info/", views.info, name="info"),
    path("invata/", views.invata, name="invata"),
    
    path('log/', views.log, name='log'),

    path('pagina_principala/', views.pagina_principala_view, name='pagina_principala'),
    path('despre/', views.despre_view, name='despre'),

    # Aici afisam produsele reale
    path('produse/', views.produse_view, name='produse'),

    path('contact/', views.contact_view, name='contact'),
    path('cos_virtual/', views.cos_virtual_view, name='cos_virtual'),
    path('inlucru/', views.inlucru, name='inlucru'),
]
